#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <omp.h>
#define MAX_LINE_LENGTH 1024

// Function to compute max ASCII value in a line (up to '\n' or null terminator)
int max_ascii_value_mpi(const char* line) {
    int max_value = 0;
    // for each character in line:
    for (int i = 0; i < MAX_LINE_LENGTH && line[i] != '\0' && line[i] != '\n'; ++i) {
        unsigned char c = (unsigned char)line[i];
        if (c <= 127 && c > max_value) { // set max value if c is greater
            max_value = c;
        }
    }
    return max_value;
}

int main(int argc, char* argv[]) {
    if (argc != 2) { // print usage pattern if there is not a file path
        fprintf(stderr, "Usage: %s <file_path>\n", argv[0]);
        return 1;
    }

    const char* file_path = argv[1]; // get file path from args

    MPI_Init(&argc, &argv); // initialize MPI

    int pid, num_procs;
    MPI_Comm_rank(MPI_COMM_WORLD, &pid); // get pid for thread
    MPI_Comm_size(MPI_COMM_WORLD, &num_procs); // get number of processes

    char (*lines)[MAX_LINE_LENGTH] = NULL;
    int num_lines = 0;

    if (pid == 0) { 
        FILE* file = fopen(file_path, "r"); // open file with lines
        if (!file) {
            fprintf(stderr, "Error opening file: %s\n", file_path); 
            MPI_Abort(MPI_COMM_WORLD, 1); // abort and notify user if error
        }

        size_t capacity = 1024;
        lines = malloc(capacity * sizeof(*lines));
        if (!lines) {
            fprintf(stderr, "Initial memory allocation failed\n");
            fclose(file);
            MPI_Abort(MPI_COMM_WORLD, 1); // abort and notify user if error
        }

        char buffer[MAX_LINE_LENGTH];
        while (fgets(buffer, MAX_LINE_LENGTH, file)) { // load each line into buffer
            if (num_lines >= capacity) {
                capacity *= 2; // increase capacity if lines exceed and reallocate memory
                char (*new_lines)[MAX_LINE_LENGTH] = realloc(lines, capacity * sizeof(*lines));
                if (!new_lines) {
                    fprintf(stderr, "Memory reallocation failed\n");
                    free(lines);
                    fclose(file);
                    MPI_Abort(MPI_COMM_WORLD, 1); // if reallocation fails, notify user and abort
                }
                lines = new_lines;
            }

            memcpy(lines[num_lines], buffer, MAX_LINE_LENGTH); // copy buffer into lines array
            num_lines++;
        }

        fclose(file); // close file
    }

    // Broadcast number of lines to all processes
    MPI_Bcast(&num_lines, 1, MPI_INT, 0, MPI_COMM_WORLD);

    // Compute send counts and displacements (in bytes)
    int* sendcounts = NULL;
    int* displs = NULL;

    if (pid == 0) {
        sendcounts = malloc(num_procs * sizeof(int)); // allocate memory for counts
        displs = malloc(num_procs * sizeof(int)); // and displacements

        int base = num_lines / num_procs;
        int rem = num_lines % num_procs;

        for (int i = 0; i < num_procs; ++i) { // calculate displacements and counts
            int count = (i < rem ? base + 1 : base);
            sendcounts[i] = count * MAX_LINE_LENGTH;
            displs[i] = (i == 0) ? 0 : displs[i - 1] + sendcounts[i - 1];
        }
    }

    struct timespec start_time, end_time;
    clock_gettime(CLOCK_MONOTONIC, &start_time);
    
    // Each process calculates how many lines it will get
    int local_line_bytes;
    // scatter sendcounts to all processes
    MPI_Scatter(sendcounts, 1, MPI_INT, &local_line_bytes, 1, MPI_INT, 0, MPI_COMM_WORLD);
    int local_line_count = local_line_bytes / MAX_LINE_LENGTH;

    char* local_lines = malloc(local_line_bytes);
    int* local_max_ascii = malloc(local_line_count * sizeof(int));

    // Scatterv lines to all processes
    MPI_Scatterv(pid == 0 ? lines : NULL, sendcounts, displs, MPI_CHAR,
                 local_lines, local_line_bytes, MPI_CHAR,
                 0, MPI_COMM_WORLD);

    // Compute local max ASCII values
    for (int i = 0; i < local_line_count; ++i) {
        local_max_ascii[i] = max_ascii_value_mpi(&local_lines[i * MAX_LINE_LENGTH]);
    }

    // Compute recvcounts and displs for gathering INTs (not bytes)
    int* recvcounts_int = NULL;
    int* displs_int = NULL;
    if (pid == 0) {
        recvcounts_int = malloc(num_procs * sizeof(int));
        displs_int = malloc(num_procs * sizeof(int));
        // calculate how many lines each process recieved
        for (int i = 0; i < num_procs; ++i) {
            recvcounts_int[i] = sendcounts[i] / MAX_LINE_LENGTH;
            displs_int[i] = (i == 0) ? 0 : displs_int[i - 1] + recvcounts_int[i - 1];
        }
    }

    int* all_max_ascii = NULL;
    if (pid == 0) {
        all_max_ascii = malloc(num_lines * sizeof(int));
    }

    // Gather all max ASCII values to root
    MPI_Gatherv(local_max_ascii, local_line_count, MPI_INT,
                all_max_ascii, recvcounts_int, displs_int, MPI_INT,
                0, MPI_COMM_WORLD);



    


    if (pid == 0) {
        for (int i = 0; i < 200; ++i) {
            printf("Line %d max ASCII: %d\n", i, all_max_ascii[i]);
        }
        clock_gettime(CLOCK_MONOTONIC, &end_time);   
        // Calculate the elapsed time in seconds
        double elapsed_time = (end_time.tv_sec - start_time.tv_sec) +
        (end_time.tv_nsec - start_time.tv_nsec) / 1e9;
    
        // Print the elapsed time
        printf("Thread time: %f seconds\n", elapsed_time);

        free(all_max_ascii);
        free(lines);
        free(sendcounts);
        free(displs);
        free(recvcounts_int);
        free(displs_int);
    }

    free(local_lines);
    free(local_max_ascii);

    MPI_Finalize(); // close MPI

    return 0;
}
